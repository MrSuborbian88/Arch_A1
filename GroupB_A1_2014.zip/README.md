Arch_A1
=======

Assignment 1 Repo

Team Members: Micah Lee, Keith Lindsey Jr, Daniel Souza, Christine Parry


##Instructions to compile (Windows):
>cd ::root of project:: 

>javac -d bin -sourcepath src src\edu\cmu\a1\PlumberSystemA.java 

>javac -d bin -sourcepath src src\edu\cmu\a1\PlumberSystemB.java 

>javac -d bin -sourcepath src src\edu\cmu\a1\PlumberSystemC.java 



##Instructions to compile (anything with sane directory seperators):

>cd ::root of project:: 

>javac -d bin -sourcepath src src/edu/cmu/a1/PlumberSystemA.java 

>javac -d bin -sourcepath src src/edu/cmu/a1/PlumberSystemB.java 

>javac -d bin -sourcepath src src/edu/cmu/a1/PlumberSystemC.java 


##Instructions to run A:
>cd ::root of project::

>java -cp ./bin edu.cmu.a1.PlumberSystemA ::Path to FlightData.dat::

##Instructions to run B:
>cd ::root of project::

>java -cp ./bin edu.cmu.a1.PlumberSystemB ::Path to FlightData.dat::

##Instructions to run C:
>cd ::root of project::

>java -cp ./bin edu.cmu.a1.PlumberSystemC ::Path to FlightData1.dat:: ::Path to FlightData2.dat::

